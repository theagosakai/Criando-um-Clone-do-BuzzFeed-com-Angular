<h1 align="center">
  BuzzFeed
</h1>

<p align="center">
  <a href="https://brunoh-buzzfeed.vercel.app/">🔗 Live Preview</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-projeto">🖥️ Projeto</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-tecnologias">🚀 Tecnologias</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#-license">📝 License</a>
</p>

<p align="center">
    <a href="https://wakatime.com/badge/user/68660678-6b86-4b78-98df-f5f41a37e1bc/project/42030f11-dc0e-42ad-af74-da2d35656193"><img src="https://wakatime.com/badge/user/68660678-6b86-4b78-98df-f5f41a37e1bc/project/42030f11-dc0e-42ad-af74-da2d35656193.svg" alt="wakatime"></a>
</p>

![Preview](./src/assets/images/preview.jfif)

## 💻 Projeto

Projeto do curso "Criando um Clone do BuzzFeed com Angular" da DIO.

## 🚀 Tecnologias

<p align="center">
  <img src="https://img.shields.io/badge/angular-%23DD0031.svg?style=for-the-badge&logo=angular&logoColor=white">
</p>

## 📝 License

Esse projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

---
